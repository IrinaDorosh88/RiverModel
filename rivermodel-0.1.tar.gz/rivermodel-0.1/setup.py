from setuptools import setup, find_packages

setup(name='rivermodel',
      version='0.1',
      description='Package for solving water grade quality problem',
      author='heroicfun',
      author_email='baier.oleksandr@chnu.edu.ua',
      packages=find_packages())